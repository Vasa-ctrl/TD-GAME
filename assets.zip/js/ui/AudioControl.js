export class AudioControl {
    constructor() {
        this.backgroundMusic = new Audio('assets/audio/background.mp3');
        this.backgroundMusic.loop = true;
        this.backgroundMusic.volume = 0.4;

        this.enemyDeathSound = new Audio('assets/audio/enemy_death.mp3');
        this.shootSound = new Audio('assets/audio/shoot.mp3');
        this.leakSound = new Audio('assets/audio/leak.mp3');

        this.isMuted = false;
    }

    playBackgroundMusic() {
        this.backgroundMusic.play().catch(error => {
            console.log("Autoplay prevented. Music will start after user interaction.");
        });
    }

    stopBackgroundMusic() {
        this.backgroundMusic.pause();
        this.backgroundMusic.currentTime = 0;
    }

    playEnemyDeath() {
        this.playSound(this.enemyDeathSound);
    }

    playShoot() {
        this.playSound(this.shootSound);
    }

    playEnemyLeak() {
        this.playSound(this.leakSound);
    }

    playSound(sound) {
        if (!this.isMuted) {
            const clone = sound.cloneNode();
            clone.volume = 0.6;
            clone.play();
        }
    }

    toggleMute() {
        this.isMuted = !this.isMuted;
        if (this.isMuted) {
            this.backgroundMusic.pause();
        } else {
            this.backgroundMusic.play();
        }
    }
}
