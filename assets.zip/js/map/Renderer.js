import { assets, TowerStats, EnemyStats } from '../config/GameAssets.js';

export class Renderer {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
    }

    /**
     * Hlavní vykreslovací metoda.
     * @param {Map} map Instance mapy obsahující všechna data.
     * @param {number} tileSize Velikost dlaždice.
     * @param {boolean} showTowerRanges Zda vykreslovat dosah věží.
     */
    render(map, tileSize, showTowerRanges) {
        // Vymazání plátna
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        if (!map.isLoaded) return;

        this.drawMapTiles(map, tileSize);
        this.drawGrid(map, tileSize);
        this.drawTowers(map.towers, tileSize, showTowerRanges);
        this.drawEnemies(map.enemies, tileSize);
        this.drawProjectiles(map.projectiles, tileSize);
    }

    drawMapTiles(map, tileSize) {
        const grid = map.levelData.grid;

        for (let y = 0; y < map.gridHeight; y++) {
            for (let x = 0; x < map.gridWidth; x++) {
                if (grid[y] && grid[y][x] !== undefined) {
                    const tileType = grid[y][x];
                    let texture;

                    // Logika pro výběr textury
                    if (tileType === 0) {
                        const number = Math.abs(((x * 7 - y ** 8) * 2 + (y * 13) - 1) * 5) % 3;
                        if (number === 0) texture = assets.tiles.solid1;
                        else if (number === 1) texture = assets.tiles.solid2;
                        else texture = assets.tiles.solid3;
                    } else {
                        texture = assets.tiles.path;
                    }

                    if (texture && texture.complete) {
                        this.ctx.drawImage(texture, x * tileSize, y * tileSize, tileSize, tileSize);
                        this.drawTileBorders(map, x, y, tileSize, tileType);
                    } else {
                        // Fallback barva
                        this.ctx.fillStyle = (tileType === 1) ? "#5a4a3a" : "#3a546d";
                        this.ctx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
                    }
                }
            }
        }
    }

    drawTileBorders(map, x, y, tileSize, tileType) {
        this.ctx.strokeStyle = 'rgba(0, 0, 0, 0.5)';
        this.ctx.lineWidth = 4;
        const grid = map.levelData.grid;

        if (y > 0 && grid[y - 1][x] !== tileType)
            this.strokeLine(x * tileSize, y * tileSize, (x + 1) * tileSize, y * tileSize);
        if (y < map.gridHeight - 1 && grid[y + 1][x] !== tileType)
            this.strokeLine(x * tileSize, (y + 1) * tileSize, (x + 1) * tileSize, (y + 1) * tileSize);
        if (x > 0 && grid[y][x - 1] !== tileType)
            this.strokeLine(x * tileSize, y * tileSize, x * tileSize, (y + 1) * tileSize);
        if (x < map.gridWidth - 1 && grid[y][x + 1] !== tileType)
            this.strokeLine((x + 1) * tileSize, y * tileSize, (x + 1) * tileSize, (y + 1) * tileSize);
    }

    drawGrid(map, tileSize) {
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        this.ctx.lineWidth = 1;
        this.ctx.beginPath();
        for (let x = 0; x <= map.gridWidth; x++) {
            this.ctx.moveTo(x * tileSize, 0);
            this.ctx.lineTo(x * tileSize, map.gridHeight * tileSize);
        }
        for (let y = 0; y <= map.gridHeight; y++) {
            this.ctx.moveTo(0, y * tileSize);
            this.ctx.lineTo(map.gridWidth * tileSize, y * tileSize);
        }
        this.ctx.stroke();
    }

    drawTowers(towers, tileSize, showRanges) {
        towers.forEach(tower => {
            if (tower.image.complete) {
                const centerX = tower.x * tileSize + tileSize / 2;
                const centerY = tower.y * tileSize + tileSize / 2;

                // Aplikujeme měřítko (scale) z logiky věže
                const currentSize = tileSize * tower.scale;
                const offset = currentSize / 2;

                this.ctx.save();

                // Efekt obtažení (záře)
                this.ctx.shadowColor = "#7F00FF";
                this.ctx.shadowBlur = 10;

                if (tower.scale > 1.0) {
                    this.ctx.shadowColor = "#00FFE1";
                    this.ctx.shadowBlur = 30;
                }

                this.ctx.drawImage(
                    tower.image,
                    centerX - offset,
                    centerY - offset,
                    currentSize,
                    currentSize
                );

                this.ctx.restore();

                // Vykreslení dosahu (pokud je zapnuto)
                if (showRanges) {
                    this.ctx.beginPath();
                    this.ctx.arc(centerX, centerY, tower.range * tileSize, 0, Math.PI * 2);
                    this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
                    this.ctx.lineWidth = 1;
                    this.ctx.stroke();
                    this.ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
                    this.ctx.fill();
                }
            }
        });
    }

    drawEnemies(enemies, tileSize) {
        enemies.forEach(enemy => {
            // 1. Vykreslení smrti (krev)
            if (enemy.isDying) {
                if (enemy.bloodImage && enemy.bloodImage.complete) {
                    const size = tileSize;
                    const offset = (tileSize - size) / 2;

                    this.ctx.save();
                    this.ctx.globalAlpha = Math.max(0, enemy.deathTimer / 30);
                    this.ctx.drawImage(
                        enemy.bloodImage,
                        enemy.x * tileSize + offset,
                        enemy.y * tileSize + offset,
                        size,
                        size
                    );
                    this.ctx.restore();
                }
                return;
            }

            // 2. Vykreslení nepřítele
            if (enemy.image && enemy.image.complete) {
                const size = tileSize * 0.8;
                const offset = (tileSize - size) / 2;
                this.ctx.drawImage(
                    enemy.image,
                    enemy.x * tileSize + offset,
                    enemy.y * tileSize + offset,
                    size,
                    size
                );
            }

            // 3. Health bar
            const hpPercentage = enemy.hp / enemy.maxHp;
            const barWidth = tileSize * 0.8;
            const barX = enemy.x * tileSize + (tileSize - barWidth) / 2;

            this.ctx.fillStyle = 'red';
            this.ctx.fillRect(barX, enemy.y * tileSize - 5, barWidth, 4);

            this.ctx.fillStyle = 'green';
            this.ctx.fillRect(barX, enemy.y * tileSize - 5, barWidth * Math.max(0, hpPercentage), 4);
        });
    }

    drawProjectiles(projectiles, tileSize) {
        projectiles.forEach(proj => {
            if (proj.image.complete && proj.image.src) {
                const size = tileSize * 0.5;
                const offset = size / 2;
                this.ctx.drawImage(
                    proj.image,
                    proj.x * tileSize - offset,
                    proj.y * tileSize - offset,
                    size,
                    size
                );
            } else {
                this.ctx.beginPath();
                this.ctx.arc(proj.x * tileSize, proj.y * tileSize, proj.radius * tileSize, 0, Math.PI * 2);
                this.ctx.fillStyle = 'yellow';
                this.ctx.fill();
                this.ctx.closePath();
            }
        });
    }

    strokeLine(x1, y1, x2, y2) {
        this.ctx.beginPath();
        this.ctx.moveTo(x1, y1);
        this.ctx.lineTo(x2, y2);
        this.ctx.stroke();
    }
}
