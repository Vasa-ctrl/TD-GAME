import { Tower } from '../models/Tower.js';
import { Enemy } from '../models/Enemy.js';

export class Map {
    constructor(gridWidth, gridHeight) {
        this.gridWidth = gridWidth;
        this.gridHeight = gridHeight;
        this.levelData = null;
        this.isLoaded = false;

        // Herní objekty
        this.towers = [];
        this.enemies = [];
        this.projectiles = [];

        // Cesta pro nepřátele
        this.path = [];
    }

    async loadLevel(levelUrl) {
        try {
            const response = await fetch(levelUrl);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            this.levelData = await response.json();

            // Najdeme cestu
            this.findPath();

            this.isLoaded = true;

            // Vyčistíme objekty
            this.towers = [];
            this.enemies = [];
            this.projectiles = [];

            console.log("Level načten, cesta nalezena:", this.path);
        } catch (error) {
            console.error("Chyba při načítání levelu:", error);
        }
    }

    /**
     * Najde cestu v mřížce (hledá sousední '1').
     */
    findPath() {
        this.path = [];
        const grid = this.levelData.grid;
        let current = null;

        // 1. Najdeme start (první '1' na okraji)
        for (let y = 0; y < this.gridHeight; y++) {
            if (grid[y][0] === 1) {
                current = { x: 0, y: y };
                break;
            }
        }

        if (!current) {
             for (let x = 0; x < this.gridWidth; x++) {
                if (grid[0][x] === 1) {
                    current = { x: x, y: 0 };
                    break;
                }
            }
        }

        if (!current) {
            console.error("Start cesty nenalezen!");
            return;
        }

        // 2. Procházíme cestu
        const visited = new Set();

        while (current) {
            this.path.push(current);
            visited.add(`${current.x},${current.y}`);

            const neighbors = [
                { x: current.x + 1, y: current.y }, // Vpravo
                { x: current.x, y: current.y + 1 }, // Dolů
                { x: current.x - 1, y: current.y }, // Vlevo
                { x: current.x, y: current.y - 1 }  // Nahoru
            ];

            let next = null;
            for (const n of neighbors) {
                if (n.x >= 0 && n.x < this.gridWidth && n.y >= 0 && n.y < this.gridHeight) {
                    if (grid[n.y][n.x] === 1 && !visited.has(`${n.x},${n.y}`)) {
                        next = n;
                        break;
                    }
                }
            }

            current = next;
        }
    }

    isBuildable(x, y) {
        if (x < 0 || x >= this.gridWidth || y < 0 || y >= this.gridHeight) return false;
        if (this.levelData.grid[y][x] !== 0) return false;
        const existingTower = this.towers.find(t => t.x === x && t.y === y);
        if (existingTower) return false;
        return true;
    }

    addTower(type, x, y) {
        const tower = new Tower(type, x, y);
        this.towers.push(tower);
    }

    spawnEnemy(type) {
        if (this.path.length === 0) return;
        const enemy = new Enemy(type, this.path);
        this.enemies.push(enemy);
    }

    update(gameSpeed) {
        let moneyEarned = 0;
        let damageTaken = 0;

        // Aktualizace věží
        this.towers.forEach(tower => tower.update(this.enemies, this.projectiles, gameSpeed));

        // Aktualizace nepřátel
        this.enemies.forEach(enemy => {
            enemy.update(gameSpeed);

            if (enemy.markedForDeletion && !enemy.isDying && !enemy.damageDealt) {
                damageTaken += 1;
                enemy.damageDealt = true;
            }

            if (enemy.isDying && !enemy.rewardClaimed) {
                moneyEarned += enemy.reward;
                enemy.rewardClaimed = true;
            }
        });

        // Odstranění mrtvých nepřátel
        this.enemies = this.enemies.filter(e => !e.markedForDeletion);

        // Aktualizace střel
        this.projectiles.forEach(proj => proj.update(gameSpeed));
        this.projectiles = this.projectiles.filter(p => !p.markedForDeletion);

        return { moneyEarned, damageTaken };
    }
}
