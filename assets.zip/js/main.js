// Soubor: js/main.js
import { Game } from './core/Game.js';
import { renderEnemyPreview } from './ui/EnemyPreview.js';
import { renderTowerPreview } from './ui/TowerPreview.js';

window.addEventListener('load', () => {
    const canvas = document.getElementById('gameCanvas');
    const mainMenu = document.getElementById('main-menu');
    const startButton = document.getElementById('start-game-btn');
    const gameUI = document.getElementById('game-ui');

    // Elementy pro nastavení
    const settingsModal = document.getElementById('settings-modal');
    const mainSettingsBtn = document.getElementById('main-settings-btn');
    const gameSettingsBtn = document.getElementById('settings-btn');
    const closeSettingsBtn = document.getElementById('close-settings-btn');
    const showRangeCheckbox = document.getElementById('show-range-checkbox');

    // Vygenerujeme UI pro nepřátele a věže z konfigurace
    renderEnemyPreview();
    renderTowerPreview();

    if (canvas && mainMenu && startButton && gameUI) {
        // Vytvoříme instanci hry
        const game = new Game(canvas);

        // --- Start hry ---
        startButton.addEventListener('click', () => {
            mainMenu.classList.add('hidden');
            gameUI.classList.remove('hidden');
            game.start('assets/levels/level1.json');
        });

        // --- Nastavení ---
        const openSettings = () => {
            if (settingsModal) {
                settingsModal.classList.remove('hidden');
                // Pokud je hra spuštěná (nejsme v hlavním menu), pauzneme ji
                if (!gameUI.classList.contains('hidden')) {
                    game.togglePause();
                }
            }
        };

        const closeSettings = () => {
            if (settingsModal) {
                settingsModal.classList.add('hidden');
                // Pokud je hra spuštěná, odpauzneme ji
                if (!gameUI.classList.contains('hidden')) {
                    game.togglePause();
                }
            }
        };

        if (mainSettingsBtn) mainSettingsBtn.addEventListener('click', openSettings);

        // Tlačítko Settings ve hře
        if (gameSettingsBtn) {
            gameSettingsBtn.addEventListener('click', () => {
                // Pokud je okno otevřené, zavřeme ho (toggle)
                if (!settingsModal.classList.contains('hidden')) {
                    closeSettings();
                } else {
                    openSettings();
                }
            });
        }

        if (closeSettingsBtn) closeSettingsBtn.addEventListener('click', closeSettings);

        // --- Funkčnost nastavení ---
        if (showRangeCheckbox) {
            // Nastavíme výchozí stav podle hry
            showRangeCheckbox.checked = game.showTowerRanges;

            // Posluchač změny
            showRangeCheckbox.addEventListener('change', (e) => {
                game.showTowerRanges = e.target.checked;
                console.log(`Zobrazování dosahu věží: ${game.showTowerRanges ? 'ZAPNUTO' : 'VYPNUTO'}`);
            });
        }

    } else {
        console.error('Některý z klíčových HTML prvků chybí!');
    }
});
