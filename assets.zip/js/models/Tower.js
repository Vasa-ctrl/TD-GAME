import { TowerStats } from '../config/GameAssets.js';
import { Projectile } from './Projectile.js';

export class Tower {
  /**
   * @param {string} type Typ věže (klíč z configu, např. 'ben').
   * @param {number} x X souřadnice v mřížce.
   * @param {number} y Y souřadnice v mřížce.
   */
  constructor(type, x, y) {
    this.type = type;
    this.x = x;
    this.y = y;

    // Načteme statistiky z konfigurace
    this.config = TowerStats[type];

    // OPRAVA: Už nevytváříme "new Image()". Bereme rovnou hotový objekt!
    this.image = this.config.image;
    this.projectileImage = this.config.projectileImage;

    // Herní vlastnosti
    this.range = this.config.range / 100 * 3; // Přepočet range na dlaždice (cca)
    this.damage = this.config.damage;
    // attackSpeed určuje, kolikrát za sekundu věž vystřelí (při 60 FPS)
    this.fireRate = 90 / ((this.config.attackSpeed || 1));

    // Časování střelby
    this.cooldown = 0;

    // Animace
    this.scale = 1.2;
  }


  /**
   * Aktualizuje stav věže (hledání cíle, střelba).
   * @param {Array} enemies Seznam všech nepřátel.
   * @param {Array} projectiles Seznam všech střel (pro přidání nové).
   * @param {number} gameSpeed Rychlost hry.
   */
  update(enemies, projectiles, gameSpeed) {
    // Animace návratu do původní velikosti
    if (this.scale > 1.2) {
      this.scale -= 0.01 * gameSpeed;
      if (this.scale < 1.2) this.scale = 1.2;
    }

    if (this.cooldown > 0) {
      this.cooldown -= gameSpeed;
      return;
    }

    const target = this.findTarget(enemies);
    if (target) {
      this.shoot(target, projectiles);
      this.cooldown = this.fireRate;
    }
  }

  /**
   * Najde nejvhodnější cíl (nejpřednější nepřítel v dosahu).
   * @param {Array} enemies
   * @returns {Enemy|null}
   */
  findTarget(enemies) {
    let bestTarget = null;
    let maxDistance = -1;

    for (const enemy of enemies) {
      // Vypočítáme vzdálenost k nepříteli (v dlaždicích)
      const dx = enemy.x - this.x;
      const dy = enemy.y - this.y;
      const distanceToEnemy = Math.sqrt(dx * dx + dy * dy);

      // Pokud je v dosahu
      if (distanceToEnemy <= this.range) {
        // A je "více vpředu" než aktuální nejlepší cíl
        if (enemy.distanceTraveled > maxDistance) {
          maxDistance = enemy.distanceTraveled;
          bestTarget = enemy;
        }
      }
    }
    return bestTarget;
  }

  shoot(target, projectiles) {
    // OPRAVA: Předáváme this.projectileImage (objekt) místo textové cesty
    projectiles.push(new Projectile(this.x + 0.5, this.y + 0.5, target, this.damage, this.projectileImage));

    // Spustíme animaci "kopnutí" (zvětšení)
    this.scale = 1.5;
  }
}
