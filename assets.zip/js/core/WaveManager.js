import { LevelWaves } from '../config/Waves.js';
import { EnemyStats } from '../config/GameAssets.js';

export class WaveManager {
    constructor(game) {
        this.game = game;
        this.currentWaveIndex = -1; // Zatím žádná vlna nezačala
        this.isWaveActive = false;

        // Fronta nepřátel k vytvoření
        this.spawnQueue = [];
        this.spawnTimer = 0;
    }

    startNextWave() {
        if (this.isWaveActive) {
            console.log("Vlna už běží!");
            return;
        }

        this.currentWaveIndex++;

        let waveConfig;

        // Pokud máme předdefinovanou vlnu, použijeme ji
        if (this.currentWaveIndex < LevelWaves.length) {
            waveConfig = LevelWaves[this.currentWaveIndex];
            console.log(`Spouštím vlnu ${this.currentWaveIndex + 1} (Předdefinovaná)`);
        } else {
            // Jinak vygenerujeme náhodnou vlnu
            waveConfig = this.generateRandomWave(this.currentWaveIndex + 1);
            console.log(`Spouštím vlnu ${this.currentWaveIndex + 1} (Náhodná)`);
        }

        this.isWaveActive = true;
        this.game.wave = this.currentWaveIndex + 1;
        this.game.updateUI();

        // Naplníme frontu nepřátel
        this.prepareSpawnQueue(waveConfig);
    }

    /**
     * Vygeneruje náhodnou vlnu na základě čísla vlny.
     * Čím vyšší vlna, tím více a silnějších nepřátel.
     */
    generateRandomWave(waveNumber) {
        const groups = [];
        const difficultyPoints = waveNumber * 100; // Body obtížnosti pro tuto vlnu
        let currentPoints = 0;

        const enemyTypes = Object.keys(EnemyStats);

        // Generujeme skupiny nepřátel, dokud nenaplníme body obtížnosti
        while (currentPoints < difficultyPoints) {
            // Vybereme náhodný typ nepřítele
            const randomType = enemyTypes[Math.floor(Math.random() * enemyTypes.length)];
            const enemyStat = EnemyStats[randomType];

            // Odhadneme "cenu" nepřítele (např. podle HP)
            const enemyCost = enemyStat.hp / 10;

            // Kolik jich můžeme přidat? (min 1, max 20)
            let count = Math.floor(Math.random() * 10) + 1;

            // Upravíme počet, abychom nepřestřelili obtížnost příliš moc
            if (currentPoints + (count * enemyCost) > difficultyPoints + 500) {
                count = Math.max(1, Math.floor((difficultyPoints - currentPoints) / enemyCost));
            }

            // Interval zrychlujeme s každou vlnou
            let interval = Math.max(200, 1500 - (waveNumber * 20));

            groups.push({
                type: randomType,
                count: count,
                interval: interval
            });

            currentPoints += count * enemyCost;
        }

        return { groups: groups };
    }

    prepareSpawnQueue(waveConfig) {
        this.spawnQueue = [];
        let currentTimeOffset = 0;

        for (const group of waveConfig.groups) {
            for (let i = 0; i < group.count; i++) {
                // Přidáme nepřítele do fronty s časem, kdy se má objevit
                this.spawnQueue.push({
                    type: group.type,
                    time: currentTimeOffset
                });

                // Posuneme čas pro dalšího nepřítele
                // Ošetření pro případ, že interval je příliš malý (např. 1 ms)
                let interval = group.interval;
                if (interval < 10) interval = 1000; // Fallback na 1 sekundu

                currentTimeOffset += interval;
            }
        }

        // Resetujeme časovač
        this.spawnTimer = 0;
    }

    update(deltaTime, gameSpeed) {
        if (!this.isWaveActive) return;

        // Přičteme uplynulý čas (v ms) vynásobený rychlostí hry
        this.spawnTimer += deltaTime * gameSpeed;

        // Kontrola fronty
        while (this.spawnQueue.length > 0) {
            // Podíváme se na prvního nepřítele ve frontě
            const nextEnemy = this.spawnQueue[0];

            if (this.spawnTimer >= nextEnemy.time) {
                // Je čas ho vytvořit
                this.game.map.spawnEnemy(nextEnemy.type);

                // Odstraníme ho z fronty
                this.spawnQueue.shift();
            } else {
                // Ještě není čas, ukončíme cyklus (fronta je seřazená podle času)
                break;
            }
        }

        // Kontrola konce vlny
        // Vlna končí, když je fronta prázdná A na mapě nejsou žádní nepřátelé
        if (this.spawnQueue.length === 0 && this.game.map.enemies.length === 0) {
            this.isWaveActive = false;
            console.log("Vlna dokončena!");
            // Zde můžeme přidat bonus za dokončení vlny
        }
    }
}
