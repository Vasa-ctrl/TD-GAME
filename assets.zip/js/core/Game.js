import { Map } from '../map/Map.js';
import { Renderer } from '../map/Renderer.js';
import { DragDrop } from '../ui/DragDrop.js';
import { WaveManager } from './WaveManager.js';
import { TowerStats, EnemyStats } from '../config/GameAssets.js';

export class Game {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');

        // Vytvoříme instanci naší nové třídy Map
        this.map = new Map(20, 12);

        // Vytvoříme renderer
        this.renderer = new Renderer(canvas);

        this.aspectRatio = this.map.gridWidth / this.map.gridHeight;
        this.tileSize = 0;

        // Herní stav
        this.lives = 20;
        this.money = 150;
        this.wave = 1;
        this.gameSpeed = 1; // Výchozí rychlost hry
        this.showTowerRanges = false;
        this.isPaused = false; // Stav pauzy

        // UI elementy
        this.uiLives = document.getElementById('ui-lives');
        this.uiMoney = document.getElementById('ui-money');
        this.uiWave = document.getElementById('ui-wave');

        this.setupUI();

        // Inicializace Drag & Drop
        this.dragDrop = new DragDrop(this, this.canvas);

        // Manažer vln
        this.waveManager = new WaveManager(this);

        // Časování
        this.lastTime = 0;

        window.addEventListener('resize', () => this.resize());
    }

    setupUI() {
        // Tlačítko pro start vlny
        const waveBtn = document.getElementById('wave-control-btn');
        if (waveBtn) {
            waveBtn.addEventListener('click', () => {
                if (!this.isPaused) {
                    this.waveManager.startNextWave();
                }
            });
        }

        // Tlačítko pro restart
        const restartBtn = document.getElementById('restart-btn');
        if (restartBtn) {
            restartBtn.addEventListener('click', () => {
                location.reload(); // Nejjednodušší restart
            });
        }

        // Tlačítka pro rychlost
        const speedBtns = document.querySelectorAll('.speed-btn');
        speedBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                // Odstraníme aktivní třídu ze všech
                speedBtns.forEach(b => b.classList.remove('active'));
                // Přidáme aktivní třídu kliknutému
                e.target.classList.add('active');

                // Nastavíme rychlost (1x nebo 2x)
                const speedText = e.target.textContent;
                this.gameSpeed = parseInt(speedText);
                console.log(`Rychlost hry nastavena na: ${this.gameSpeed}x`);
            });
        });
    }

    async start(levelUrl) {
        // Delegujeme načítání na mapu
        await this.map.loadLevel(levelUrl);

        // Načteme počáteční peníze z levelu, pokud jsou definovány
        if (this.map.levelData && this.map.levelData.startingMoney) {
            this.money = this.map.levelData.startingMoney;
        }

        this.updateUI();
        this.resize();

        // Spustíme smyčku s časovým razítkem
        requestAnimationFrame((timestamp) => this.animate(timestamp));
    }

    updateUI() {
        if (this.uiLives) this.uiLives.textContent = `Lives: ${this.lives}`;
        if (this.uiMoney) this.uiMoney.textContent = `Money: ${this.money}`;
        if (this.uiWave) this.uiWave.textContent = `Wave: ${this.wave}`;
    }

    togglePause() {
        this.isPaused = !this.isPaused;
        console.log(`Hra ${this.isPaused ? 'POZASTAVENA' : 'SPUŠTĚNA'}`);
    }

    /**
     * Pokusí se postavit věž na daných souřadnicích.
     * @param {string} type Typ věže (klíč z TowerStats).
     * @param {number} x X souřadnice v mřížce.
     * @param {number} y Y souřadnice v mřížce.
     */
    buildTower(type, x, y) {
        if (this.isPaused) return; // Nelze stavět v pauze

        const towerConfig = TowerStats[type];

        if (!towerConfig) {
            console.error(`Neznámý typ věže: ${type}`);
            return;
        }

        // 1. Kontrola peněz
        if (this.money < towerConfig.price) {
            console.log("Nedostatek peněz!");
            return;
        }

        // 2. Kontrola, zda je místo validní (pomocí Mapy)
        if (!this.map.isBuildable(x, y)) {
            console.log("Zde nelze stavět!");
            return;
        }

        // Vše OK -> Stavíme
        console.log(`Stavím věž ${towerConfig.name} na [${x}, ${y}]`);

        this.money -= towerConfig.price;
        this.map.addTower(type, x, y); // Přidáme věž do mapy
        this.updateUI();
    }

    takeDamage(amount) {
        this.lives = Math.max(0, this.lives - amount);
        this.updateUI();

        if (this.lives === 0) {
            console.log("Game Over!");
            this.isPaused = true; // Zastavíme hru
            // Zde by se měla zobrazit obrazovka prohry
        }
    }

    resize() {
        const container = this.canvas.parentElement;
        const containerWidth = container.clientWidth;
        const containerHeight = container.clientHeight;

        let newWidth = containerWidth;
        let newHeight = newWidth / this.aspectRatio;

        if (newHeight > containerHeight) {
            newHeight = containerHeight;
            newWidth = newHeight * this.aspectRatio;
        }

        this.canvas.width = newWidth;
        this.canvas.height = newHeight;
        this.tileSize = this.canvas.width / this.map.gridWidth;
    }

    animate(timestamp) {
        if (!this.map.isLoaded) return;

        if (!this.lastTime) this.lastTime = timestamp;

        // Výpočet deltaTime (v ms)
        const deltaTime = timestamp - this.lastTime;
        this.lastTime = timestamp;

        // Pokud NENÍ pauza, aktualizujeme logiku
        if (!this.isPaused) {
            // 1. Aktualizace logiky
            this.waveManager.update(deltaTime, this.gameSpeed);

            const updateResult = this.map.update(this.gameSpeed);

            let moneyEarned = 0;
            let damageTaken = 0;

            if (updateResult) {
                moneyEarned = updateResult.moneyEarned || 0;
                damageTaken = updateResult.damageTaken || 0;
            }

            if (damageTaken > 0) this.takeDamage(damageTaken);

            if (moneyEarned > 0) {
                this.money += moneyEarned;
                this.updateUI();
            }
        }

        // 2. Vykreslení pomocí Renderer (kreslíme i v pauze, aby nezmizel obraz)
        this.renderer.render(this.map, this.tileSize, this.showTowerRanges);

        // Pokud je pauza, můžeme přes renderer vykreslit "PAUSED" text
        if (this.isPaused && this.lives > 0) { // Nekreslit PAUSED při Game Over
            this.ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
            this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

            this.ctx.fillStyle = 'white';
            this.ctx.font = '40px Consolas';
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            this.ctx.fillText('PAUSED', this.canvas.width / 2, this.canvas.height / 2);
        }

        requestAnimationFrame((ts) => this.animate(ts));
    }
}
